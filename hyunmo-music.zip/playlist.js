// 노래 플레이어 목록
// 1) mp3 파일을 이 music 폴더에 올리세요. 파일 이름은 영어로 해두면 안전해요.
// 2) 아래 목록에 한 줄씩 적어주세요. 첫 줄이 첫 곡이에요.
//    disc 에 음악 목록의 곡 제목을 똑같이 적으면, 그 곡 옆에 ▶ 버튼이 생겨요.
export const PLAYLIST = [
  { title: "Gravity", file: "music/gravity.mp3" },
  { title: "Fine", file: "music/fine.mp3" },
  { title: "현모의 노래", file: "music/song-08.mp3" }, // ← 실제 곡 제목으로 바꿔주세요
];

// 들어오자마자 재생을 시도할지 (브라우저가 막으면 화면을 처음 누를 때 시작돼요)
export const AUTO_START = true;
